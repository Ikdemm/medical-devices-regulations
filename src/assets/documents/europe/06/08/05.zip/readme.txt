This zip archive contains 5 XSD files and 2 XSL files. 


The 5 XSD files correspond to the types of MIR form that reflect the reporting stages:
------------------------------------------
- Initial
- Follow up
- Combined initial and final
- Final (Reportable incident)
- Final (Non-reportable incident)

The files describe the structure of the XML for each type of form. The XSD files also provide data type for each element.


The 2 XSL files are incorporated in the PDF form and they are used as follows:
-----------
- incident_in_7.0.xsl: this transformation is applied to the XML file that is being imported (i.e. when the button Import XML is clicked)

- incident_out_7.0.xsl: this transformation is applied when the XML file is generated (i.e. when the button send XML is clicked)

In case you intend to automatise above import and export XML functions in your system, make sure that these transformations are properly applied and fully functional.
